package com.geometric.main;

import com.geometric.go.*;

public class Ejecucion {

	public static void main(String[] args) {

		Geome G = new Geome();
		G.setTitle("Dinamico Geometria");
		G.setVisible(true);
		G.setLocationRelativeTo(null);
	}

}
